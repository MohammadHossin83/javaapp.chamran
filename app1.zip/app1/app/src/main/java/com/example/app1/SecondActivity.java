package com.example.app1;

import android.content.Intent;

import  android.net.Uri;
import  android.os.Bundle;
import  android.view.View;
import  android.widget.Button;
import  androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    private Button btnOpenGoogle,btnCall,btnSendMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        btnOpenGoogle =
                findViewById(R.id.btnOpenGoogle);
        btnCall =
                findViewById(R.id.btnCall);
        btnSendMessage =
                findViewById(R.id.btnSendMessage);

        btnOpenGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com"));
                startActivity(intent);
            }
        });
        btnCall.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent intent = new Intent(Intent.ACTION_DIAL,Uri.parse("tel:09027885344"));
        startActivity(intent);
    }
        });

        btnSendMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:zangimoha@gmail.com"));
                startActivity(intent);
            }
        });



    }
}