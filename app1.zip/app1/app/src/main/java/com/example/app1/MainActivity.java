package com.example.app1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

   private EditText usernameEditText,passwordEditText;
   private Button loginButton;
   private TextView messageTextView;

   @Override
    protected void onCreate(Bundle savedInstanceState){
       super .onCreate(savedInstanceState);
       setContentView(R.layout.activity_main);

       usernameEditText = findViewById(R.id.username);
       passwordEditText = findViewById(R.id.password);
       loginButton =findViewById(R.id.loginButton);
       messageTextView = findViewById(R.id.message);


       loginButton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               String username =usernameEditText.getText().toString();
               String password =passwordEditText.getText().toString();


               if (username.isEmpty() || password.isEmpty()) {
                   messageTextView.setText("نام کاربری و رمز عبور را وارد کنید");
               } else  {
                   if (username.equals("ADMIN") && password.equals("pas123456")) {
                       messageTextView.setText("");
                       Toast.makeText(MainActivity.this,"خوش امدید",Toast.LENGTH_SHORT).show();

                       Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                       startActivity(intent);
                       finish();
                   }
                   else {
                       messageTextView.setText("نام کاربری یا رمز عبور اشتباه است");
                   }
               }

           }
       });




   }




}